from django.contrib import admin
from django.urls import path, re_path

from . import views

urlpatterns = [
    path('ocr/ocr_write', views.ocr_write, name='ocr_write'),
    path('ocr/ocr_list', views.ocr_list, name='ocr_list'),
    path('ocr/ocr_view', views.ocr_view, name='ocr_view'),
    re_path('ocr/download', views.file_response_download, name='file_response_download'),
    path('ocr/ocr_setup', views.ocr_setup, name='ocr_setup'),
    path('ocr/ocr_guide', views.ocr_guide, name='ocr_guide'),
    path('ocr/opencv_guide', views.opencv_guide, name='opencv_guide'),
    path('ocr/pytorch_guide', views.pytorch_guide, name='pytorch_guide'),
    path('ocr/detectme', views.detectme, name="detectme"),
    path('ocr/etc_guide', views.etc_guide, name="etc_guide"),
]