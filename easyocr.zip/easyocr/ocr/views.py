from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
import os
from PIL import Image
from io import StringIO
import pytesseract
from .models import CHSource
from datetime import datetime
import easyocr
import cv2
from django.core.paginator import Paginator
from django.shortcuts import render
from PyPDF2 import PdfReader
from tika import parser
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.http import FileResponse
from django.http import HttpResponse, Http404, StreamingHttpResponse
from django.views.decorators import gzip
from django.http import StreamingHttpResponse
import threading

# from myapp.models import Contact

pytesseract.pytesseract.tesseract_cdm = "C:/Program Files/Tesseract-OCR/tesseract.exe"

# Create your views here.

def ocr_write(request):
    context = {}
    context['menutitle'] = 'OCR READ'
    context['bo_type'] = 'OCR'

    imgname = ''
    resulttext = ''
    returnUrl = 'ocr/ocr_write.html'
    if 'uploadfile' in request.FILES:
        uploadfile = request.FILES.get('uploadfile', '')
        returnUrl = 'ocr/ocr_list.html'

        if uploadfile != '':
            name_old = uploadfile.name
            name_ext = os.path.splitext(name_old)[1]

            img_type = name_old.split('.')[len(name_old.split('.')) - 1].upper()

            print("img_type2=" + img_type + ", size=" + str(len(name_old.split('.'))))

            fs = FileSystemStorage(location='static/source')
            if 'PDF' in img_type:
                imgname = fs.save(f"src-{name_old}", uploadfile)
                print("path=" + str(getattr(settings, 'FILE_SAVE', None) + imgname))
                raw = parser.from_file(getattr(settings, 'FILE_SAVE', None) + imgname)
                print("1.2")
                resulttext = raw['content']
                # except:
                #     print("error1")
                CHSource.objects.create(src_file=name_old,
                                        src_name=imgname,
                                        src_link=f"/static/souce/{imgname}",
                                        result_text=resulttext,
                                        ocr_type='pdf_ocr',
                                        img_type='img_type',
                                        created_at=datetime.now())

            elif 'easyOcr' in request.POST['ocr_type']:
                print(cv2.__version__)
                imgname = fs.save(f"src-{name_old}", uploadfile)
                print(str(f"./static/source/{imgname}"))
                with open(f"./static/source/{imgname}", "rb") as f:
                    img = f.read()

                print("[INFO] OCR'ing input image...")
                reader = easyocr.Reader(['ko', 'en'], gpu=True)
                print("----------------------------------------------------------------------")
                resulttext = reader.readtext(img)
                print(resulttext)
                imgText = ''
                for ii in str(resulttext).split("'"):
                    print("*******************************************************" + ii)
                    if not ii.startswith(",") or ii.startswith('[') or ii.startswith('",'):  # [([[ ",",
                        imgText += " " + ii
                        print(imgText)
                    print("*******************************************************")

                print("---------------------------------------------------------------------")
                # resulttext = reader.readtext(image)

                print(request.POST['ocr_type'])
                # resulttext = resulttext.replace(" ","")

                CHSource.objects.create(src_file=name_old,
                                        src_name=imgname,
                                        src_link=f"/static/souce/{imgname}",
                                        result_text=imgText,
                                        ocr_type=request.POST['ocr_type'],
                                        img_type='img_type',
                                        created_at=datetime.now())
            else:
                imgname = fs.save(f"src-{name_old}", uploadfile)
                print("path=" + str(f"./static/souce/{imgname}"))
                imgfile = Image.open(f"./static/source/{imgname}")
                print("imgfile=" + str(imgfile))

                resulttext = pytesseract.image_to_string(imgfile, lang='eng+kor')
                # resulttext = resulttext.replace(" ","")
                CHSource.objects.create(src_file=name_old,
                                        src_name=imgname,
                                        src_link=f"/static/souce/{imgname}",
                                        result_text=resulttext,
                                        ocr_type='tesseract',
                                        img_type='img_type',
                                        created_at=datetime.now())

    if 'ocr/ocr_list.html' in returnUrl:
        PAGE_COUNT = getattr(settings, 'PAGE_COUNT', None)
        rsSource = CHSource.objects.filter().order_by('-id')
        paginator = Paginator(rsSource, PAGE_COUNT)
        page_number = request.POST.get('page')
        page_obj = paginator.get_page(page_number)
        page_number = 1
        total_count = rsSource.count()
        context['page_obj'] = page_obj
        context['rsSource'] = rsSource
        page_number = 1
        context['total_count'] = total_count
        context['bo_type'] = 'OCR'
        context['sub_menu_title'] = 'OCR 리스트'

    context['imgname'] = imgname
    context['resulttext'] = resulttext  # .replace(" ","")
    context['sub_menu_title'] = 'OCR 만들기'
    print("returnUrl=" + returnUrl)
    return render(request, returnUrl, context)

def ocr_list(request):
    print("ocr/ocr_list.html")
    context = {}
    context['menutitle'] = 'OCR목록'

    rsSource = CHSource.objects.filter().order_by('-id')
    total_count = rsSource.count()
    paginator = Paginator(rsSource, 12)
    page_number = request.GET.get('page')
    if page_number is None:
        page_number = 1
    page_obj = paginator.get_page(page_number)
    print("page=" + str(page_number) + " , pageLen=" + str(page_obj))
    context['page_obj'] = page_obj
    context['rsSource'] = rsSource
    context['total_count'] = total_count
    context['bo_type'] = 'OCR'
    context['sub_menu_title'] = 'OCR 리스트'

    return render(request, 'ocr/ocr_list.html', context)

def ocr_view(request):
    print("ocr/ocr_view.html")
    context = {}
    context['bo_type'] = 'OCR'
    context['sub_menu_title'] = 'OCR 내용 상세보기'
    bno = request.GET['id']

    rsData = CHSource.objects.get(id=bno)
    print("rsData.bo_hit=" + str(rsData.bo_hit))
    hit = rsData.bo_hit

    if rsData.bo_hit is not None:
        hit = 0
    rsData.bo_hit = hit + 1
    print("bno=" + bno)
    rsData.save()
    rsDetail1 = CHSource.objects.filter(id=bno)
    # print("rsDetail2="+str(rsDetail1.src_file))
    context['rsDetail1'] = rsDetail1
    return render(request, 'ocr/ocr_view.html', context)

def file_response_download(request):
    file_path = request.GET['file_path']
    file_path = "./static/source/" + file_path
    ext = os.path.basename(file_path).split('.')[-1].lower()
    # cannot be used to download py, db and sqlite3 files.
    if ext not in ['py', 'db', 'sqlite3']:
        response = FileResponse(open(file_path, 'rb'))
        response['content_type'] = "application/octet-stream"
        response['Content-Disposition'] = 'attachment; filename=' + os.path.basename(file_path)
        return response
    else:
        raise Http404


def ocr_setup(request):
    print("ocr/ocr_setup.html")
    context = {}
    context['bo_type'] = 'OCR'
    context['sub_menu_title'] = 'OCR설치가이드'

    return render(request, 'ocr/ocr_setup.html', context)


def ocr_guide(request):
    print("ocr/ocr_guide.html")
    context = {}
    context['bo_type'] = 'OCR'
    context['sub_menu_title'] = 'OCR가이드'

    return render(request, 'ocr/ocr_guide.html', context)


def opencv_guide(request):
    print("ocr/opencv_guide.html")
    context = {}
    context['bo_type'] = 'OCR'
    context['sub_menu_title'] = 'OPEN CV'

    return render(request, 'ocr/opencv_guide.html', context)


def pytorch_guide(request):
    print("ocr/pytorch_guide.html")
    context = {}
    context['bo_type'] = 'OCR'
    context['sub_menu_title'] = 'PYTORCH CV'

    return render(request, 'ocr/pytorch_guide.html', context)


class VideoCamera(object):
    def __init__(self):
        print("217")
        self.video = cv2.VideoCapture(0)
        print("219")
        (self.grabbed, self.frame) = self.video.read()
        print("221")
        threading.Thread(target=self.update, args=()).start()
        print("223")

    def __del__(self):
        self.video.release()

    def get_frame(self):
        print("228")
        image = self.frame
        _, jpeg = cv2.imencode('.jpg', image)
        print("231")
        return jpeg.tobytes()

    def update(self):
        while True:
            (self.grabbed, self.frame) = self.video.read()


def gen(camera):
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')


@gzip.gzip_page
def detectme(request):
    try:
        print("1")
        cam = VideoCamera()
        print("2")
        return StreamingHttpResponse(gen(cam), content_type="multipart/x-mixed-replace;boundary=frame")
    except:  # This is bad! replace it with proper handling
        print("에러입니다...")
        pass


def etc_guide(request):
    print("ocr/ocr_guide.html")
    context = {}
    context['bo_type'] = 'OCR'
    context['sub_menu_title'] = 'OCR가이드'

    return render(request, 'ocr/etc_guide.html', context)